﻿namespace calculadora
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblnum1 = new System.Windows.Forms.Label();
            this.lblnum2 = new System.Windows.Forms.Label();
            this.lblresultado = new System.Windows.Forms.Label();
            this.txtnum1 = new System.Windows.Forms.TextBox();
            this.txtnum3 = new System.Windows.Forms.TextBox();
            this.txtnum2 = new System.Windows.Forms.TextBox();
            this.btnlimpar = new System.Windows.Forms.Button();
            this.lblsair = new System.Windows.Forms.Button();
            this.btndiv = new System.Windows.Forms.Button();
            this.btnmult = new System.Windows.Forms.Button();
            this.btnsub = new System.Windows.Forms.Button();
            this.btnadd = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblnum1
            // 
            this.lblnum1.AutoSize = true;
            this.lblnum1.Location = new System.Drawing.Point(101, 71);
            this.lblnum1.Name = "lblnum1";
            this.lblnum1.Size = new System.Drawing.Size(78, 20);
            this.lblnum1.TabIndex = 0;
            this.lblnum1.Text = "Número 1";
            // 
            // lblnum2
            // 
            this.lblnum2.AutoSize = true;
            this.lblnum2.Location = new System.Drawing.Point(101, 139);
            this.lblnum2.Name = "lblnum2";
            this.lblnum2.Size = new System.Drawing.Size(78, 20);
            this.lblnum2.TabIndex = 1;
            this.lblnum2.Text = "Número 2";
            // 
            // lblresultado
            // 
            this.lblresultado.AutoSize = true;
            this.lblresultado.Location = new System.Drawing.Point(101, 215);
            this.lblresultado.Name = "lblresultado";
            this.lblresultado.Size = new System.Drawing.Size(82, 20);
            this.lblresultado.TabIndex = 2;
            this.lblresultado.Text = "Resultado";
            // 
            // txtnum1
            // 
            this.txtnum1.Location = new System.Drawing.Point(221, 71);
            this.txtnum1.Name = "txtnum1";
            this.txtnum1.Size = new System.Drawing.Size(173, 26);
            this.txtnum1.TabIndex = 3;
            this.txtnum1.TextChanged += new System.EventHandler(this.TextBox1_TextChanged);
            this.txtnum1.Validated += new System.EventHandler(this.Txtnum1_Validated);
            // 
            // txtnum3
            // 
            this.txtnum3.Enabled = false;
            this.txtnum3.Location = new System.Drawing.Point(221, 215);
            this.txtnum3.Name = "txtnum3";
            this.txtnum3.Size = new System.Drawing.Size(173, 26);
            this.txtnum3.TabIndex = 4;
            // 
            // txtnum2
            // 
            this.txtnum2.Location = new System.Drawing.Point(221, 139);
            this.txtnum2.Name = "txtnum2";
            this.txtnum2.Size = new System.Drawing.Size(173, 26);
            this.txtnum2.TabIndex = 5;
            this.txtnum2.TextChanged += new System.EventHandler(this.TextBox3_TextChanged);
            this.txtnum2.Validated += new System.EventHandler(this.Txtnum2_Validated);
            // 
            // btnlimpar
            // 
            this.btnlimpar.Location = new System.Drawing.Point(527, 71);
            this.btnlimpar.Name = "btnlimpar";
            this.btnlimpar.Size = new System.Drawing.Size(109, 57);
            this.btnlimpar.TabIndex = 6;
            this.btnlimpar.Text = "Limpar";
            this.btnlimpar.UseVisualStyleBackColor = true;
            this.btnlimpar.Click += new System.EventHandler(this.Btnlimpar_Click);
            // 
            // lblsair
            // 
            this.lblsair.Location = new System.Drawing.Point(527, 184);
            this.lblsair.Name = "lblsair";
            this.lblsair.Size = new System.Drawing.Size(109, 57);
            this.lblsair.TabIndex = 7;
            this.lblsair.Text = "Sair";
            this.lblsair.UseVisualStyleBackColor = true;
            this.lblsair.Click += new System.EventHandler(this.Lblsair_Click);
            // 
            // btndiv
            // 
            this.btndiv.Location = new System.Drawing.Point(555, 324);
            this.btndiv.Name = "btndiv";
            this.btndiv.Size = new System.Drawing.Size(81, 49);
            this.btndiv.TabIndex = 8;
            this.btndiv.Text = "/";
            this.btndiv.UseVisualStyleBackColor = true;
            this.btndiv.Click += new System.EventHandler(this.Btndiv_Click);
            // 
            // btnmult
            // 
            this.btnmult.Location = new System.Drawing.Point(399, 324);
            this.btnmult.Name = "btnmult";
            this.btnmult.Size = new System.Drawing.Size(80, 49);
            this.btnmult.TabIndex = 9;
            this.btnmult.Text = "*";
            this.btnmult.UseVisualStyleBackColor = true;
            this.btnmult.Click += new System.EventHandler(this.Btnmult_Click);
            // 
            // btnsub
            // 
            this.btnsub.Location = new System.Drawing.Point(242, 324);
            this.btnsub.Name = "btnsub";
            this.btnsub.Size = new System.Drawing.Size(79, 49);
            this.btnsub.TabIndex = 10;
            this.btnsub.Text = "-";
            this.btnsub.UseVisualStyleBackColor = true;
            this.btnsub.Click += new System.EventHandler(this.Btnsub_Click);
            // 
            // btnadd
            // 
            this.btnadd.Location = new System.Drawing.Point(75, 324);
            this.btnadd.Name = "btnadd";
            this.btnadd.Size = new System.Drawing.Size(77, 49);
            this.btnadd.TabIndex = 11;
            this.btnadd.Text = "+";
            this.btnadd.UseVisualStyleBackColor = true;
            this.btnadd.Click += new System.EventHandler(this.Btnadd_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnadd);
            this.Controls.Add(this.btnsub);
            this.Controls.Add(this.btnmult);
            this.Controls.Add(this.btndiv);
            this.Controls.Add(this.lblsair);
            this.Controls.Add(this.btnlimpar);
            this.Controls.Add(this.txtnum2);
            this.Controls.Add(this.txtnum3);
            this.Controls.Add(this.txtnum1);
            this.Controls.Add(this.lblresultado);
            this.Controls.Add(this.lblnum2);
            this.Controls.Add(this.lblnum1);
            this.Name = "Form1";
            this.Text = "Calculadora";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblnum1;
        private System.Windows.Forms.Label lblnum2;
        private System.Windows.Forms.Label lblresultado;
        private System.Windows.Forms.TextBox txtnum1;
        private System.Windows.Forms.TextBox txtnum3;
        private System.Windows.Forms.TextBox txtnum2;
        private System.Windows.Forms.Button btnlimpar;
        private System.Windows.Forms.Button lblsair;
        private System.Windows.Forms.Button btndiv;
        private System.Windows.Forms.Button btnmult;
        private System.Windows.Forms.Button btnsub;
        private System.Windows.Forms.Button btnadd;
    }
}

