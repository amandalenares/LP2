﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace calculadora
{
    public partial class Form1 : Form
    {
        double numero1, numero2, resultado; //globais
        public Form1()
        {
            InitializeComponent();
        }

        private void TextBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void Btnlimpar_Click(object sender, EventArgs e)
        {
            txtnum1.Text = "";
            txtnum2.Text = "";
            txtnum3.Text = "";
            // volta para o numero 1 e limpa variaveis 
            txtnum1.Focus();
            resultado = 0;
            numero1 = 0;
            numero2 = 0;


        }

        private void Txtnum1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtnum1.Text, out numero1))
            {
                MessageBox.Show("Número 1 inválido!");
                txtnum1.Focus();
            }
        }

        private void Txtnum2_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtnum2.Text, out numero2))
            {
                MessageBox.Show("Número 2 inválido!");
                txtnum2.Focus();
            }
        }

        private void Btnadd_Click(object sender, EventArgs e)
        {
            resultado = numero1 + numero2;
            txtnum3.Text = resultado.ToString();
            
        }

        private void Btnsub_Click(object sender, EventArgs e)
        {
            resultado = numero1 - numero2;
            txtnum3.Text = resultado.ToString();
        }

        private void Btnmult_Click(object sender, EventArgs e)
        {
            resultado = numero1 * numero2;
            txtnum3.Text = resultado.ToString();
        }

        private void Btndiv_Click(object sender, EventArgs e)
        {
            if (numero2 == 0)
            {
                MessageBox.Show("não pode dividir por zero!", "ERRO",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtnum2.Focus();
            }
            else
            {
                resultado = numero1 / numero2;
                txtnum3.Text = resultado.ToString();
            }
        }

        private void Lblsair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você deseja realmente sair?",
                "Saída", MessageBoxButtons.YesNo,
                MessageBoxIcon.Question) == 
                DialogResult.Yes)
            {
                Close();
            }
        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
