﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IMC2
{
    public partial class Form1 : Form
    {
        double massa, altura, imc;

        private void txtaltura_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtaltura.Text, out altura) || altura > 2.6)
            {
                MessageBox.Show("Valor inválido");
                txtaltura.Focus();
            }
        }

        private void btncalc_Click(object sender, EventArgs e)
        {
        
            
                if ((altura <= 0) || (massa <= 0))
                    MessageBox.Show("Valores devem ser maiores que zero!");
                else
                {
                    imc = massa / (Math.Pow(altura, 2));
                    imc = Math.Round(imc, 1); //arrendodei

                    txtimc.Text = imc.ToString("N1");

                    if (imc < 18.5)
                        MessageBox.Show("Magreza");
                    else if (imc <= 24.9)
                        MessageBox.Show("Normal");
                    else if (imc <= 29.9)
                        MessageBox.Show("Sobrepeso");
                    else if (imc <= 39.9)
                        MessageBox.Show("Obesidade");
                    else
                        MessageBox.Show("Obesidade grave");

                }
            }

        private void button2_Click(object sender, EventArgs e)
        {
            txtmassa.Text = "";
            txtaltura.Text = "";
            // volta para o numero 1 e limpa variaveis 
            txtmassa.Focus();
            imc = 0;
            massa = 0;
            altura = 0;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você deseja realmente sair?",
               "Saída", MessageBoxButtons.YesNo,
               MessageBoxIcon.Question) ==
               DialogResult.Yes)
            {
                Close();
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void txtmassa_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtmassa.Text, out massa) || massa > 300)
            {
                MessageBox.Show("Valor inválido");
                txtmassa.Focus();
            }
        }
    }
}
