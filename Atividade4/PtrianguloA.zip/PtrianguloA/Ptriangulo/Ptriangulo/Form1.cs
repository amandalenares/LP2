﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        

        private void Txt1_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(txt1, "");
            double valorA;
            
            if(!double.TryParse(txt1.Text, out valorA))
            {
                errorProvider1.SetError(txt1, "Valor de A inválido!");
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Txt2_Validated(object sender, EventArgs e)
        {
            errorProvider2.SetError(txt2, "");
            double valorB;

            if (!double.TryParse(txt2.Text, out valorB))
            {
                errorProvider2.SetError(txt2, "Valor de B inválido!");
            }
        }

        private void Txt3_Validated(object sender, EventArgs e)
        {
            errorProvider3.SetError(txt3, "");
            double valorC;

            if (!double.TryParse(txt3.Text, out valorC))
            {
                errorProvider3.SetError(txt3, "Valor de C inválido!");
            }
        }

        private void Btncalc_Click(object sender, EventArgs e)
        {
            double valorA = 0, valorB = 0, valorC = 0;

            if (!double.TryParse(txt1.Text, out valorA) ||
                !double.TryParse(txt2.Text, out valorB) ||
                !double.TryParse(txt3.Text, out valorC))

            {
               
                MessageBox.Show("os valores devem ser numéricos");
            }
            else
            {
                
                //condicao necessaria p ser triangulo
                if (valorA < (valorB + valorC) && valorA >
                    Math.Abs(valorB - valorC) && valorB < (valorA + valorC)
                    && valorB > Math.Abs(valorA - valorC)
                    && valorC < (valorA + valorB) &&
                    valorC > Math.Abs(valorA - valorB))

                {
                    if (valorA == valorB && valorB == valorC)
                        MessageBox.Show($"os valores {valorA}, {valorB} e {valorC} formam um triangulo equilatero");
                    else
                    {
                        if (valorA == valorB || valorA == valorC || valorC == valorB)

                            MessageBox.Show($"os valores {valorA}, {valorB} e {valorC} formam um triangulo isoceles");
                        else
                            MessageBox.Show($"os valores {valorA}, {valorB} e {valorC} formam um triangulo escaleno");

                    }
                }
                else
                    MessageBox.Show($"os valores {valorA}, {valorB} e {valorC}  não formam um triangulo");
                }

            }

        private void Btnlimpar_Click(object sender, EventArgs e)
        {
            txt1.Text = "";
            txt2.Text = "";
            txt3.Text = "";
            txt1.Focus();

        }

        private void Btnsair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("voce deseja realmente sair?",
                "saida", MessageBoxButtons.YesNo,
                MessageBoxIcon.Question) == DialogResult.Yes)

            {
                Close();
            }
        }
    }
}
